import "module-alias/register";

import { Chron } from './chron';

const chron: Chron = new Chron();

chron.start();
