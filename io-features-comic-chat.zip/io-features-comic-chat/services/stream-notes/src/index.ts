import "module-alias/register";

import { StreamNotes } from './stream-notes';

const streamNotes: StreamNotes = new StreamNotes();

streamNotes.start();
