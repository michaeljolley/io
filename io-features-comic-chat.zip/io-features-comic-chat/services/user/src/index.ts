import "module-alias/register";

import { User } from './user';

const user: User = new User();

user.start();
