export interface IGithubIssue {
  html_url: string;
  id: number;
  number: number;
  title: string;
  body: string;
}