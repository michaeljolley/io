
export interface IBaseEventArg {

}
