import { IBaseEventArg } from "./baseEventArg";

export interface IFollowerCountEventArg extends IBaseEventArg {
  followers: number;
}
