import { IBaseEventArg } from "./baseEventArg";

export interface IViewerCountEventArg extends IBaseEventArg {
  viewers: number;
}
