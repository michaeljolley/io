import { IBaseEventArg } from "./baseEventArg";

export interface IUserLeftEventArg extends IBaseEventArg {
  username: string;
}
