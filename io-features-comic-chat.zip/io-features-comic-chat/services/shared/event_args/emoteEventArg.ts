import { IBaseEventArg } from "./baseEventArg";

export interface IEmoteEventArg extends IBaseEventArg {
  emoteUrl: string;
}
