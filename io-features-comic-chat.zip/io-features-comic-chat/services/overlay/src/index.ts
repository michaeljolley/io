import "module-alias/register";

import { Overlay } from './overlay';

const overlay: Overlay = new Overlay();

overlay.start();
