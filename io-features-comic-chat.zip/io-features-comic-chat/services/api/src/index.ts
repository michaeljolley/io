import "module-alias/register";

import { API } from './api';

const api: API = new API();

api.start();
