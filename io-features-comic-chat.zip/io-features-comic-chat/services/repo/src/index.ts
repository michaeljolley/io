import "module-alias/register";

import { Repo } from './repo';

const repo: Repo = new Repo();

repo.start();
